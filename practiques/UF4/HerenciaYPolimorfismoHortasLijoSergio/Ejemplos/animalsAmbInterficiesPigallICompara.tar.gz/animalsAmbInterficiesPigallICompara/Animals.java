package animalsAmbInterficiesPigallICompara;

import java.util.ArrayList;

public class Animals  { 
  
   public ArrayList<Animal> animals; 
   public Compara criteriComparador;  
   
   public Animals(Compara criteriComparador) {
     this.animals =  new ArrayList<Animal>();
     this.criteriComparador = criteriComparador;
   }
   
}