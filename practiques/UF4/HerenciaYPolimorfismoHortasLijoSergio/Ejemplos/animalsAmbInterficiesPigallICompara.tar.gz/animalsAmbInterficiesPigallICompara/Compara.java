package animalsAmbInterficiesPigallICompara;

public interface Compara
{
   public abstract boolean compara(Animal a1, Animal a2);
}