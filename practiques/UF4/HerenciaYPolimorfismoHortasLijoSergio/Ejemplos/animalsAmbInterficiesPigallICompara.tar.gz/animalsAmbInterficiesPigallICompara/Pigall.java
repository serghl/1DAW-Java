
package animalsAmbInterficiesPigallICompara;

public interface Pigall
{
   public String treball();
}
