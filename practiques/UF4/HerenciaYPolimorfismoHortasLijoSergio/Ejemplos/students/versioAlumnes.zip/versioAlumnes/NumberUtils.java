/*
 * ComputerStudent.java            
 *
 * Copyright 2017 Rafel Botey
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 *
 */

package versioAlumnes;


public final class NumberUtils { // Al ser final fem aquesta classe NO Tingui classes filles
  
 private NumberUtils(){  // Definim els constructor com a privat per tant NO podrem mai instanciar cap objecte NumberUtils
  
 }
 /*
 public static double avg(double op1, double op2) {
     return (op1 + op2) / 2;
 }
    
 public static double avg(double op1, double op2, double op3) {
     return (op1 + op2 + op3) / 3;
 }
 */   
 public static double avg(double ... ops) { 
      double sum = 0;
      for (int i = 0; i < ops.length ; i++){
           sum = sum + ops[i];
       }
       return sum / ops.length;
  }
 
  public static double maximum(double ... ops) { 
    
    return 0;
  }
  
  public static double minimum(double ... ops) { 
   
    return 0;
  }
}
